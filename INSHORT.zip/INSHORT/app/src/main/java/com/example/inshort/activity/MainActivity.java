package com.example.inshort.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;

import com.example.inshort.R;
import com.example.inshort.adapter.VerticalPagerAdapter;
import com.example.inshort.helper.VerticlePagerAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> tempArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tempArrayList.add("first");
        tempArrayList.add("second");
        tempArrayList.add("third");
        tempArrayList.add("fourth");
        tempArrayList.add("five");
        tempArrayList.add("six");
        tempArrayList.add("seven");
        tempArrayList.add("eight");

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        getSupportActionBar().hide();
        initSwipePager();

    }

    private void initSwipePager(){

        VerticalPagerAdapter verticalViewPagerAdapter = findViewById(R.id.vPager);
        verticalViewPagerAdapter.setAdapter(new VerticlePagerAdapter(this,tempArrayList));

    }

}
